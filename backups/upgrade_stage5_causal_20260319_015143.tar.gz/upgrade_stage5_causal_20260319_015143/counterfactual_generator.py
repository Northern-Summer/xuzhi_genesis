#!/usr/bin/env python3
"""
反事实推演生成器：基于知识图谱和本地模型，生成反事实假设任务。
"""
import json
import sqlite3
import random
import requests
import sys
from pathlib import Path
from datetime import datetime, timedelta

# 路径配置
KNOWLEDGE_DB = Path.home() / "xuzhi_genesis" / "centers" / "intelligence" / "knowledge" / "knowledge.db"
TASKS_JSON = Path.home() / ".openclaw" / "tasks" / "tasks.json"
LOG_FILE = Path.home() / "xuzhi_genesis" / "logs" / "counterfactual.log"
OLLAMA_URL = "http://localhost:11434/api/generate"

# 本地模型名称
MODEL = "qwen3.5:4b"

def log(msg):
    """写入日志"""
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

def load_json(path):
    with open(path) as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def get_random_entity_pair():
    """从知识图谱中随机选取一对有关系的实体（优先因果关系）"""
    conn = sqlite3.connect(KNOWLEDGE_DB)
    c = conn.cursor()
    # 先尝试找有因果关系的关系（predicate 包含 "cause" 等）
    c.execute('''
        SELECT e1.name, e2.name, r.confidence, r.predicate
        FROM relations r
        JOIN entities e1 ON r.subject_id = e1.id
        JOIN entities e2 ON r.object_id = e2.id
        WHERE r.predicate LIKE '%cause%' OR r.predicate LIKE '%lead%' OR r.predicate LIKE '%result%'
        ORDER BY RANDOM() LIMIT 1
    ''')
    row = c.fetchone()
    if row:
        conn.close()
        return row[0], row[1], row[2], row[3]
    # 如果没有明确因果关系，随机取一对关系
    c.execute('''
        SELECT e1.name, e2.name, r.confidence, r.predicate
        FROM relations r
        JOIN entities e1 ON r.subject_id = e1.id
        JOIN entities e2 ON r.object_id = e2.id
        ORDER BY RANDOM() LIMIT 1
    ''')
    row = c.fetchone()
    conn.close()
    if row:
        return row[0], row[1], row[2], row[3]
    return None, None, None, None

def generate_counterfactual(entity1, entity2, predicate, confidence):
    """调用本地模型生成反事实问题"""
    prompt = f"""基于以下已知关系生成一个反事实问题：
实体1: {entity1}
实体2: {entity2}
关系: {predicate}
置信度: {confidence}

请生成一个“如果……会怎样”的反事实问题，探索如果这个关系不成立或相反时的情况。
只输出问题本身，不要额外解释。"""
    try:
        resp = requests.post(OLLAMA_URL, json={
            "model": MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.8, "max_tokens": 100}
        }, timeout=30)
        resp.raise_for_status()
        result = resp.json()
        question = result.get("response", "").strip()
        return question
    except Exception as e:
        log(f"模型调用失败: {e}")
        return None

def create_counterfactual_task(question, entity1, entity2):
    """将反事实问题作为验证任务插入任务中心"""
    with open(TASKS_JSON) as f:
        data = json.load(f)

    new_task = {
        "id": data["next_id"],
        "title": question,
        "type": "验证假设",
        "subtype": "counterfactual",  # 新增字段，标记为反事实
        "department": "science",       # 默认给科学部
        "mode": "competition",
        "description": question,
        "hypothesis": {
            "entity1": entity1,
            "entity2": entity2,
            "relation": None,  # 可后续填充
            "counterfactual": True
        },
        "created": datetime.now().isoformat(),
        "deadline": (datetime.now() + timedelta(days=2)).isoformat(),
        "status": "等待",
        "participants": [],
        "participant_times": {},
        "completed_by": [],
        "completion_time": None,
        "evaluations": {},
        "score_processed": False
    }

    data["tasks"].append(new_task)
    data["next_id"] += 1
    data["last_updated"] = datetime.now().isoformat()

    save_json(TASKS_JSON, data)
    return new_task["id"]

def main():
    log("开始反事实生成周期")
    e1, e2, conf, pred = get_random_entity_pair()
    if not e1:
        log("图谱中无可用实体对，跳过")
        return

    question = generate_counterfactual(e1, e2, pred, conf)
    if not question:
        log("生成问题失败")
        return

    task_id = create_counterfactual_task(question, e1, e2)
    log(f"生成反事实任务 ID {task_id}: {question}")

if __name__ == "__main__":
    main()
