#!/usr/bin/env python3
"""
知识提炼引擎：从种子文件中提取结构化知识，存入 SQLite 图谱。
使用 qwen3.5:4b 模型进行本地推理。
"""

import os
import re
import json
import sqlite3
import hashlib
import subprocess
from datetime import datetime
from typing import List, Dict, Any, Tuple
import requests

# 配置
PROJECT_ROOT = "/home/summer/xuzhi_genesis"
INTEL_DIR = os.path.join(PROJECT_ROOT, "centers/intelligence")
SEEDS_DIR = os.path.join(INTEL_DIR, "seeds")
KNOWLEDGE_DIR = os.path.join(INTEL_DIR, "knowledge")
DB_PATH = os.path.join(KNOWLEDGE_DIR, "knowledge.db")
PROCESSED_LOG = os.path.join(KNOWLEDGE_DIR, "processed_seeds.txt")
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen3.5:4b"  # 修正为正确的模型

# 种子类型定义（与蓝图一致）
SEED_TYPES = [
    "paradigm_shift", "contradiction", "cross_domain_link",
    "testable_hypothesis", "anomaly", "methodology_innovation",
    "predictive_insight", "meta_cognition", "consensus_break",
    "hidden_connection", "cognitive_tool", "antifragile_point"
]

# ==================== 数据库初始化 ====================

def init_db():
    """初始化 SQLite 知识图谱表"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS entities (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT,  -- person, organization, concept, technology
        source TEXT,
        first_seen TIMESTAMP,
        last_seen TIMESTAMP,
        confidence REAL
    )''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS relations (
        id TEXT PRIMARY KEY,
        subject_id TEXT,
        predicate TEXT,
        object_id TEXT,
        source TEXT,
        first_seen TIMESTAMP,
        confidence REAL,
        FOREIGN KEY(subject_id) REFERENCES entities(id),
        FOREIGN KEY(object_id) REFERENCES entities(id)
    )''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS seed_entities (
        seed_file TEXT,
        entity_id TEXT,
        FOREIGN KEY(entity_id) REFERENCES entities(id)
    )''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS seed_types (
        seed_file TEXT PRIMARY KEY,
        seed_type TEXT,
        confidence REAL
    )''')
    
    conn.commit()
    conn.close()
    print("✅ 知识图谱数据库初始化完成")

# ==================== 已处理种子记录 ====================

def get_processed_seeds():
    if not os.path.exists(PROCESSED_LOG):
        return set()
    with open(PROCESSED_LOG, 'r') as f:
        return set(line.strip() for line in f)

def mark_seed_processed(seed_file):
    with open(PROCESSED_LOG, 'a') as f:
        f.write(seed_file + "\n")

# ==================== 调用 Ollama 进行提取 ====================

def extract_with_ollama(text: str) -> Dict[str, Any]:
    """调用本地 qwen3.5:4b 模型提取实体、关系、类型"""
    # 限制输入文本长度，避免超时
    if len(text) > 3000:
        text = text[:3000] + "..."
    
    prompt = f"""
    请从以下文本中提取结构化信息，并以 JSON 格式返回。

    文本：
    {text}

    要求：
    1. 实体：识别出的人名、机构名、概念名、技术名，每个实体包含 name 和 type（person/organization/concept/technology）。
    2. 关系：识别实体之间的语义关系，每条关系包含 subject（实体名）、predicate（关系词）、object（实体名）。
    3. 类型：根据以下分类，判断文本最符合哪种种子类型（返回一个字符串）：
       {', '.join(SEED_TYPES)}
       如果不属于任何类型，返回 "general"。

    只输出 JSON，不要其他解释。
    """
    
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "temperature": 0.1,
        "max_tokens": 1024
    }
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
        resp.raise_for_status()
        result = resp.json()
        response_text = result.get("response", "")
        # 提取 JSON 部分
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
            # 确保字段存在
            if "entities" not in data:
                data["entities"] = []
            if "relations" not in data:
                data["relations"] = []
            if "type" not in data:
                data["type"] = "general"
            return data
        else:
            print("  警告：无法解析模型输出，返回空数据")
            return {"entities": [], "relations": [], "type": "general"}
    except requests.exceptions.Timeout:
        print("  错误：Ollama 请求超时")
        return {"entities": [], "relations": [], "type": "general"}
    except Exception as e:
        print(f"  错误：Ollama 调用失败 - {e}")
        return {"entities": [], "relations": [], "type": "general"}

# ==================== 知识入库 ====================

def generate_entity_id(name: str) -> str:
    return hashlib.sha256(name.encode()).hexdigest()[:16]

def store_knowledge(seed_file: str, content: str, extracted: Dict[str, Any]):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.now().isoformat()
    
    # 存储种子类型
    seed_type = extracted.get("type", "general")
    confidence = 0.8
    c.execute('''INSERT OR REPLACE INTO seed_types (seed_file, seed_type, confidence)
                  VALUES (?, ?, ?)''', (seed_file, seed_type, confidence))
    
    # 存储实体
    entity_ids = {}
    for ent in extracted.get("entities", []):
        name = ent["name"]
        etype = ent.get("type", "concept")
        eid = generate_entity_id(name)
        entity_ids[name] = eid
        c.execute('SELECT id FROM entities WHERE id = ?', (eid,))
        if c.fetchone():
            c.execute('''UPDATE entities SET last_seen = ? WHERE id = ?''', (now, eid))
        else:
            c.execute('''INSERT INTO entities (id, name, type, source, first_seen, last_seen, confidence)
                          VALUES (?, ?, ?, ?, ?, ?, ?)''',
                      (eid, name, etype, seed_file, now, now, 0.8))
    
    # 存储关系
    for rel in extracted.get("relations", []):
        subj = rel.get("subject", "")
        pred = rel.get("predicate", "")
        obj = rel.get("object", "")
        if subj in entity_ids and obj in entity_ids:
            subj_id = entity_ids[subj]
            obj_id = entity_ids[obj]
            rel_id = hashlib.sha256(f"{subj_id}{pred}{obj_id}".encode()).hexdigest()[:16]
            c.execute('''INSERT OR IGNORE INTO relations (id, subject_id, predicate, object_id, source, first_seen, confidence)
                          VALUES (?, ?, ?, ?, ?, ?, ?)''',
                      (rel_id, subj_id, pred, obj_id, seed_file, now, 0.7))
    
    # 关联种子-实体
    for name, eid in entity_ids.items():
        c.execute('''INSERT OR IGNORE INTO seed_entities (seed_file, entity_id) VALUES (?, ?)''',
                  (seed_file, eid))
    
    conn.commit()
    conn.close()
    print(f"  入库完成: 实体 {len(entity_ids)} 个, 关系 {len(extracted.get('relations', []))} 条")

# ==================== 主流程 ====================

def process_new_seeds():
    processed = get_processed_seeds()
    seed_files = sorted([f for f in os.listdir(SEEDS_DIR) if f.endswith('.md')])
    new_seeds = [f for f in seed_files if f not in processed]
    
    if not new_seeds:
        print("没有新的种子文件需要处理。")
        return
    
    print(f"发现 {len(new_seeds)} 个新种子文件，开始提取知识...")
    for idx, seed_file in enumerate(new_seeds, 1):
        print(f"\n[{idx}/{len(new_seeds)}] 处理 {seed_file}...")
        seed_path = os.path.join(SEEDS_DIR, seed_file)
        with open(seed_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        extracted = extract_with_ollama(content)
        print(f"  提取结果: 类型={extracted.get('type','unknown')}, "
              f"实体数={len(extracted.get('entities',[]))}, "
              f"关系数={len(extracted.get('relations',[]))}")
        
        store_knowledge(seed_file, content, extracted)
        mark_seed_processed(seed_file)
    
    print(f"\n✅ 知识提取完成，共处理 {len(new_seeds)} 个文件。")

def main():
    init_db()
    process_new_seeds()

if __name__ == "__main__":
    main()
